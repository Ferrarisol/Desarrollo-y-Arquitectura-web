const titulo = document.getElementById("titulo");
const formulario = document.getElementById("formulario");

const nombre = document.getElementById("nombre");
const email = document.getElementById("email");
const password = document.getElementById("password");
const repetirPassword = document.getElementById("repetirPassword");
const edad = document.getElementById("edad");
const telefono = document.getElementById("telefono");
const direccion = document.getElementById("direccion");
const ciudad = document.getElementById("ciudad");
const cp = document.getElementById("cp");
const dni = document.getElementById("dni");

nombre.addEventListener("keyup", () => {
    titulo.textContent = nombre.value.trim()
        ? "HOLA " + nombre.value.toUpperCase()
        : "HOLA";
});

function mostrarError(input, mensaje){
    input.classList.add("is-invalid");
    input.classList.remove("is-valid");

    input.nextElementSibling.textContent = mensaje;
}

function mostrarOk(input){
    input.classList.remove("is-invalid");
    input.classList.add("is-valid");

    input.nextElementSibling.textContent = "";
}

function validarNombre(){
    const valor = nombre.value.trim();

    if(valor.length <= 6 || !valor.includes(" ")){
        mostrarError(nombre,"Debe tener más de 6 letras y un espacio.");
        return false;
    }

    mostrarOk(nombre);
    return true;
}

function validarEmail(){
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if(!regex.test(email.value)){
        mostrarError(email,"Email inválido.");
        return false;
    }

    mostrarOk(email);
    return true;
}

function validarPassword(){
    const regex = /^(?=.*[A-Za-z])(?=.*\d).{8,}$/;

    if(!regex.test(password.value)){
        mostrarError(password,"Mínimo 8 caracteres con letras y números.");
        return false;
    }

    mostrarOk(password);
    return true;
}

function validarRepetirPassword(){

    if(password.value !== repetirPassword.value){
        mostrarError(repetirPassword,"Las contraseñas no coinciden.");
        return false;
    }

    mostrarOk(repetirPassword);
    return true;
}

function validarEdad(){

    const valor = Number(edad.value);

    if(valor < 18){
        mostrarError(edad,"Debe ser mayor o igual a 18.");
        return false;
    }

    mostrarOk(edad);
    return true;
}

function validarTelefono(){

    if(!/^\d{7,}$/.test(telefono.value)){
        mostrarError(telefono,"Debe tener al menos 7 dígitos.");
        return false;
    }

    mostrarOk(telefono);
    return true;
}

function validarDireccion(){

    const valor = direccion.value.trim();

    if(valor.length < 5 || !valor.includes(" ")){
        mostrarError(direccion,"Debe tener al menos 5 caracteres y un espacio.");
        return false;
    }

    mostrarOk(direccion);
    return true;
}

function validarCiudad(){

    if(ciudad.value.trim().length < 3){
        mostrarError(ciudad,"Mínimo 3 caracteres.");
        return false;
    }

    mostrarOk(ciudad);
    return true;
}

function validarCP(){

    if(cp.value.trim().length < 3){
        mostrarError(cp,"Mínimo 3 caracteres.");
        return false;
    }

    mostrarOk(cp);
    return true;
}

function validarDNI(){

    if(!/^\d{7,8}$/.test(dni.value)){
        mostrarError(dni,"Debe contener entre 7 y 8 dígitos.");
        return false;
    }

    mostrarOk(dni);
    return true;
}

nombre.addEventListener("blur", validarNombre);
email.addEventListener("blur", validarEmail);
password.addEventListener("blur", validarPassword);
repetirPassword.addEventListener("blur", validarRepetirPassword);
edad.addEventListener("blur", validarEdad);
telefono.addEventListener("blur", validarTelefono);
direccion.addEventListener("blur", validarDireccion);
ciudad.addEventListener("blur", validarCiudad);
cp.addEventListener("blur", validarCP);
dni.addEventListener("blur", validarDNI);

formulario.addEventListener("submit", function(e){

    e.preventDefault();

    const valido =
        validarNombre() &&
        validarEmail() &&
        validarPassword() &&
        validarRepetirPassword() &&
        validarEdad() &&
        validarTelefono() &&
        validarDireccion() &&
        validarCiudad() &&
        validarCP() &&
        validarDNI();

    if(valido){

        alert(`
Nombre: ${nombre.value}
Email: ${email.value}
Edad: ${edad.value}
Teléfono: ${telefono.value}
Dirección: ${direccion.value}
Ciudad: ${ciudad.value}
CP: ${cp.value}
DNI: ${dni.value}
        `);

        formulario.reset();
        titulo.textContent = "HOLA";

    }else{
        alert("Existen errores en el formulario.");
    }
});